package com.lanny.web.utils;

public class MsgSyn {

    public final static int QUERY_LATEST_BLOCK = 1;
    public final static int RESPONSE_LATEST_BLOCK = 2;
    public final static int QUERY_BLOCKCHAIN = 3;
    public final static int RESPONSE_BLOCKCHAIN = 4;
    public final static int QUERY_RECEIVER = 5;
    public final static int RESPONSE_RECEIVER = 6;
    public final static int TRANS_INFO = 7;
}
